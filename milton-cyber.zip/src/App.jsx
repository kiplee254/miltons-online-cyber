
import { useState } from "react";
import { motion } from "framer-motion";
import { Mail, Phone, Globe, MessageCircle } from "lucide-react";

export default function App() {
  const [form, setForm] = useState({ name: "", email: "", message: "" });

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    alert("Message sent! (Form handling not yet connected)");
    setForm({ name: "", email: "", message: "" });
  };

  const services = [
    "Printing & Photocopying",
    "Document Typing",
    "Scanning & Emailing",
    "KRA PIN & iTax Services",
    "eCitizen Applications",
    "NHIF & NSSF Services",
    "Online Form Filling",
    "Lamination & Binding"
  ];

  return (
    <div className="min-h-screen bg-gray-50 text-gray-800">
      {/* Hero Section */}
      <section className="flex flex-col items-center justify-center text-center py-20 px-4 bg-gradient-to-r from-blue-500 to-indigo-600 text-white">
        <motion.h1
          className="text-4xl md:text-6xl font-bold mb-4"
          initial={{ opacity: 0, y: -30 }}
          animate={{ opacity: 1, y: 0 }}
        >
          Milton's Online Cyber
        </motion.h1>
        <motion.p
          className="text-lg md:text-2xl mb-6"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.3 }}
        >
          Your one-stop online cyber services hub
        </motion.p>
        <button className="bg-white text-blue-600 rounded-2xl px-6 py-3 text-lg shadow hover:bg-gray-100">
          Get Started
        </button>
      </section>

      {/* Services Section */}
      <section className="py-16 px-6 md:px-12 bg-white">
        <h2 className="text-3xl font-bold text-center mb-12">Our Services</h2>
        <div className="grid md:grid-cols-3 gap-8">
          {services.map((service, i) => (
            <div key={i} className="shadow-md rounded-2xl p-6 text-center bg-gray-50">
              <h3 className="text-xl font-semibold mb-3">{service}</h3>
              <p className="text-gray-600">
                Reliable and fast {service.toLowerCase()} to keep you moving.
              </p>
            </div>
          ))}
        </div>
      </section>

      {/* About Section */}
      <section className="py-16 px-6 md:px-20 bg-gray-100">
        <h2 className="text-3xl font-bold text-center mb-8">About Us</h2>
        <p className="max-w-3xl mx-auto text-center text-lg text-gray-700">
          At Milton's Online Cyber, we are committed to providing quick, affordable,
          and reliable cyber services. From document handling to government portals,
          we ensure you get the help you need without hassle.
        </p>
      </section>

      {/* Contact Section */}
      <section className="py-16 px-6 md:px-20 bg-white">
        <h2 className="text-3xl font-bold text-center mb-8">Contact Us</h2>
        <div className="grid md:grid-cols-2 gap-12">
          {/* Contact Info */}
          <div className="space-y-4 text-lg">
            <p className="flex items-center gap-3">
              <Phone />
              <a href="tel:+254723674605" className="text-blue-600 hover:underline">
                +254 723 674 605
              </a>
            </p>
            <p className="flex items-center gap-3">
              <Mail />
              <a href="mailto:mkipleting94@gmail.com" className="text-blue-600 hover:underline">
                mkipleting94@gmail.com
              </a>
            </p>
            <p className="flex items-center gap-3">
              <MessageCircle />
              <a
                href="https://wa.me/254723674605"
                target="_blank"
                rel="noopener noreferrer"
                className="text-blue-600 hover:underline"
              >
                Chat on WhatsApp
              </a>
            </p>
            <p className="flex items-center gap-3">
              <Globe /> www.miltoncyber.com
            </p>
          </div>

          {/* Contact Form */}
          <form onSubmit={handleSubmit} className="space-y-4">
            <input
              type="text"
              name="name"
              value={form.name}
              onChange={handleChange}
              placeholder="Your Name"
              className="w-full border rounded-xl p-3"
              required
            />
            <input
              type="email"
              name="email"
              value={form.email}
              onChange={handleChange}
              placeholder="Your Email"
              className="w-full border rounded-xl p-3"
              required
            />
            <textarea
              name="message"
              value={form.message}
              onChange={handleChange}
              placeholder="Your Message"
              className="w-full border rounded-xl p-3"
              rows="4"
              required
            ></textarea>
            <button
              type="submit"
              className="bg-blue-600 text-white rounded-2xl px-6 py-3 w-full hover:bg-blue-700"
            >
              Send Message
            </button>
          </form>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-800 text-gray-300 text-center py-6 mt-12">
        <p>© {new Date().getFullYear()} Milton's Online Cyber. All rights reserved.</p>
      </footer>
    </div>
  );
}
